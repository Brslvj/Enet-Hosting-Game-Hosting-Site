ENET Hosting website template
1. Open index.html in a browser, or upload all files to your web hosting public_html folder.
2. Replace each https://example.com link with your real order, panel, free-server and contact URLs.
3. Change the support email and location/service text in index.html as needed.
4. Edit colors, spacing and layout in style.css.
The design is responsive and uses Google Fonts (Orbitron and Rajdhani); an internet connection is needed for those fonts.
Game artwork is recreated with CSS gradients and typography placeholders, so you can replace each .game-image background with your own game images.
